<?php $__env->startSection('title', 'Thùng rác bài học'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid p-4">

        <!-- ===== HEADER ===== -->
        <div class="d-flex align-items-center justify-content-between rounded border bg-white p-4 shadow-sm mb-4">
            <h2 class="h4 fw-semibold mb-0 text-dark">
                Thùng rác bài học
            </h2>

            <a href="<?php echo e(route('lesson.index')); ?>"
                class="d-inline-flex align-items-center gap-2 rounded bg-secondary px-4 py-2 text-white text-decoration-none shadow-sm">
                <i class="fa-solid fa-arrow-left"></i>
                <span>Quay lại danh sách</span>
            </a>
        </div>

        <!-- ===== TABLE ===== -->
        <div class="rounded border bg-white shadow-sm overflow-hidden">
            <div class="table-responsive">
                <table class="table table-hover mb-0 align-middle">
                    <thead class="table-light">
                        <tr class="text-secondary">
                            <th class="px-4 py-3">Tiêu đề</th>
                            <th class="px-4 py-3">Level</th>
                            <th class="px-4 py-3 text-center">Ngày xóa</th>
                            <th class="px-4 py-3 text-center">Thao tác</th>
                            <th class="px-4 py-3 text-center">ID</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="hover-bg-light">

                                <td class="px-4 py-3 fw-medium text-danger">
                                    <?php echo e($item->title); ?>

                                </td>

                                <td class="px-4 py-3">
                                    <?php echo e($item->level?->level_name ?? '—'); ?>

                                </td>

                                <td class="px-4 py-3 text-center text-secondary">
                                    <?php echo e($item->deleted_at?->format('d/m/Y H:i')); ?>

                                </td>

                                <td class="px-4 py-3 text-center">
                                    <div class="d-inline-flex align-items-center gap-3">

                                        <!-- Restore -->
                                        <a href="<?php echo e(route('lesson.restore', $item->id)); ?>" title="Khôi phục"
                                            class="text-success text-decoration-none">
                                            <i class="fa-solid fa-rotate-left fs-5"></i>
                                        </a>

                                        <!-- Force delete -->
                                        <form action="<?php echo e(route('lesson.forceDelete', $item->id)); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit">
                                                <a href="" class="btn btn-sm btn-danger"><i
                                                        class="fa-solid fa-trash"></i></a>
                                            </button>
                                        </form>
                                    </div>
                                </td>

                                <td class="px-4 py-3 text-center text-secondary">
                                    <?php echo e($item->id); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="text-center text-muted py-4">
                                    Thùng rác trống
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <div class="border-top p-4">
                <?php echo e($list->links()); ?>

            </div>
        </div>
    </div>

    <style>
        .hover-bg-light:hover {
            background-color: rgba(0, 0, 0, 0.02);
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\backendenglish\resources\views/admin/lesson/trash.blade.php ENDPATH**/ ?>