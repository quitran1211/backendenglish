<?php $__env->startSection('title', 'Thùng rác - Từ vựng'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid p-4">

        
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="h4 fw-semibold mb-1 text-danger">
                    <i class="fa-solid fa-trash"></i> Thùng rác từ vựng
                </h2>
                <div class="text-muted">Danh sách từ vựng đã bị xóa</div>
            </div>

            <a href="<?php echo e(route('vocabularies.index')); ?>" class="btn btn-secondary">
                <i class="fa-solid fa-arrow-left"></i> Quay lại
            </a>
        </div>

        
        <div class="rounded border bg-white shadow-sm">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Từ vựng</th>
                            <th>Loại từ</th>
                            <th>Nghĩa (VI)</th>
                            <th class="text-center">Ngày xóa</th>
                            <th class="text-center">Thao tác</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $vocabularies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vocab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="fw-semibold"><?php echo e($vocab->word); ?></td>

                                <td>
                                    <span class="badge bg-info text-dark">
                                        <?php echo e($vocab->word_type ?? 'N/A'); ?>

                                    </span>
                                </td>

                                <td><?php echo e($vocab->meaning_vi); ?></td>

                                <td class="text-center text-muted">
                                    <?php echo e($vocab->deleted_at?->format('d/m/Y H:i')); ?>

                                </td>

                                <td class="text-center">
                                    <div class="d-inline-flex gap-2">

                                        
                                        <form action="<?php echo e(route('vocabularies.restore', $vocab->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <button class="btn btn-sm btn-success">
                                                <i class="fa-solid fa-rotate-left"></i> Khôi phục
                                            </button>
                                        </form>

                                        
                                        <form action="<?php echo e(route('vocabularies.forceDelete', $vocab->id)); ?>" method="POST"
                                            onsubmit="return confirm('Xóa vĩnh viễn từ vựng này?')">
                                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                            <button class="btn btn-sm btn-danger">
                                                <i class="fa-solid fa-trash"></i> Xóa hẳn
                                            </button>
                                        </form>

                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="text-center text-muted py-4">
                                    Thùng rác trống
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            
            <?php if($vocabularies->hasPages()): ?>
                <div class="p-3 border-top">
                    <?php echo e($vocabularies->links()); ?>

                </div>
            <?php endif; ?>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\backendenglish\resources\views/admin/vocabularies/trash.blade.php ENDPATH**/ ?>