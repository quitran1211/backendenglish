<?php $__env->startSection('title', 'Quản lý Người dùng'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid p-4">

        <!-- ===== HEADER ===== -->
        <div class="d-flex align-items-center justify-content-between rounded border bg-white p-4 shadow-sm mb-4">
            <h2 class="h4 fw-semibold mb-0 text-dark">
                Quản lý Người dùng
            </h2>

            <div class="d-flex align-items-center gap-3">

                <!-- Thêm người dùng -->
                <a href="<?php echo e(route('user.create')); ?>"
                    class="d-inline-flex align-items-center gap-2 rounded
                      bg-primary px-4 py-2 text-white text-decoration-none
                      shadow-sm transition hover:bg-primary-dark">
                    <i class="fa-solid fa-plus"></i>
                    <span>Thêm người dùng</span>
                </a>

                <!-- Thùng rác -->
                <a href="<?php echo e(route('user.trash')); ?>"
                    class="d-inline-flex align-items-center gap-2 rounded
                      bg-danger px-4 py-2 text-white text-decoration-none
                      shadow-sm transition hover:bg-danger-dark">
                    <i class="fa-solid fa-trash"></i>
                    <span>Thùng rác</span>
                </a>
            </div>
        </div>


        <!-- ===== TABLE ===== -->
        <div class="rounded border bg-white shadow-sm overflow-hidden">
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead class="table-light">
                        <tr class="text-secondary">
                            <th class="px-4 py-3" style="width: 50px;">
                                <input type="checkbox" id="select-all" class="form-check-input">
                            </th>
                            <th class="px-4 py-3">Người dùng</th>
                            <th class="px-4 py-3">Username</th>
                            <th class="px-4 py-3">Vai trò</th>
                            <th class="px-4 py-3 text-center">Mức độ</th>
                            <th class="px-4 py-3 text-center">Điểm mục tiêu</th>
                            <th class="px-4 py-3 text-center">Loại TK</th>
                            <th class="px-4 py-3 text-center"></th>

                        </tr>
                    </thead>

                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="hover-bg-light">
                                <td class="px-4 py-3">
                                    <input type="checkbox" class="form-check-input user-checkbox"
                                        value="<?php echo e($item->id); ?>" <?php echo e($item->id === auth()->id() ? 'disabled' : ''); ?>>
                                </td>

                                <td class="px-4 py-3">
                                    <div class="d-flex align-items-center gap-3">
                                        <img src="<?php echo e($item->avatar); ?>" alt="<?php echo e($item->full_name); ?>" class="rounded-circle"
                                            style="width: 40px; height: 40px; object-fit: cover;">
                                        <div>
                                            <div class="fw-medium"><?php echo e($item->full_name ?? 'Chưa cập nhật'); ?></div>
                                            <small class="text-muted"><?php echo e($item->email); ?></small>
                                        </div>
                                    </div>
                                </td>

                                <td class="px-4 py-3">
                                    <span class="badge bg-secondary bg-opacity-10 text-secondary px-3 py-2">
                                        <?php echo e($item->username); ?>

                                    </span>
                                </td>

                                <td class="px-4 py-3 ">
                                    <span class="px-3 py-2 badge bg-primary bg-opacity-10 text-secondary">
                                        <?php echo e($item->role); ?>

                                    </span>
                                </td>

                                <td class="px-4 py-3 text-center">
                                    <?php if($item->currentLevel): ?>
                                        <span class="badge <?php echo e($item->currentLevel->badge_class); ?> px-3 py-2">
                                            <?php echo e($item->currentLevel->level_name); ?>

                                        </span>
                                    <?php else: ?>
                                        <span class="text-muted">Chưa chọn</span>
                                    <?php endif; ?>
                                </td>

                                <td class="px-4 py-3 text-center">
                                    <?php if($item->target_score): ?>
                                        <span class="badge bg-warning bg-opacity-10 text-warning px-3 py-2">
                                            <?php echo e($item->target_score); ?>

                                        </span>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>

                                <!-- Chức năng -->
                                <td class="px-4 py-3 text-center">
                                    <div class="d-inline-flex align-items-center gap-2">

                                        <!-- View Progress -->
                                        <a href="<?php echo e(route('user.progress', $item->id)); ?>"
                                            class="text-info text-decoration-none transition-transform hover-scale"
                                            title="Tiến độ học tập">
                                            <i class="fa-solid fa-chart-line"></i>
                                        </a>

                                        <!-- Edit -->
                                        <a href="<?php echo e(route('user.edit', $item->id)); ?>"
                                            class="text-primary text-decoration-none transition-transform hover-scale"
                                            title="Chỉnh sửa">
                                            <i class="fa-solid fa-pen-to-square"></i>
                                        </a>

                                        <!-- Delete -->
                                        <a href="<?php echo e(route('user.delete', $item->id)); ?>"
                                            class="text-danger text-decoration-none transition-transform hover-scale"
                                            title="Xóa" onclick="return confirm('Bạn có chắc muốn xóa người dùng này?')">
                                            <i class="fa-solid fa-trash"></i>
                                        </a>

                                    </div>
                                </td>
                                <td class="px-4 py-3 text-center">
                                    <!-- View -->
                                    <a href="<?php echo e(route('user.show', $item->id)); ?>" class="text-primary text-decoration-none"
                                        title="Xem chi tiết">
                                        Xem
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="9" class="text-center py-5 text-muted">
                                    <i class="fa-solid fa-users fs-1 mb-3 d-block"></i>
                                    <p class="mb-0">Chưa có người dùng nào</p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Bulk Actions & Pagination -->
            <div class="border-top p-4">
                <div class="row align-items-center">
                    <div class="col-md-6 d-flex justify-content-end">
                        <?php echo e($list->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('styles'); ?>
        <style>
            .hover-scale:hover {
                transform: scale(1.1);
            }

            .hover-underline:hover {
                text-decoration: underline !important;
            }

            .hover-bg-light:hover {
                background-color: rgba(0, 0, 0, 0.02) !important;
            }

            .bg-primary-dark:hover {
                background-color: #0b5ed7 !important;
            }

            .bg-danger-dark:hover {
                background-color: #bb2d3b !important;
            }

            .badge-danger {
                background-color: #f8d7da !important;
                color: #842029 !important;
            }

            .badge-warning {
                background-color: #fff3cd !important;
                color: #664d03 !important;
            }

            .badge-primary {
                background-color: #cfe2ff !important;
                color: #084298 !important;
            }
        </style>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\backendenglish\resources\views/admin/user/index.blade.php ENDPATH**/ ?>