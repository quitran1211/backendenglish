<aside class="bg-dark text-white vh-100 p-3 position-sticky top-0 flex-shrink-0" style="width:260px;">
    <h5 class="text-center mb-4 fw-bold">ADMIN PANEL</h5>
    <ul class="nav nav-pills flex-column gap-2">
        <li>
            <a href="<?php echo e(route('admin.dashboard')); ?>"
                class="nav-link <?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?> d-flex align-items-center gap-2">
                <i class="fa-solid fa-gauge"></i>
                Dashboard
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('levels.index')); ?>"
                class="nav-link <?php echo e(request()->routeIs('course.*') ? 'active' : ''); ?> d-flex align-items-center gap-2">
                <i class="fa-solid fa-box"></i>
                Quản lý cấp độ
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('lesson.index')); ?>"
                class="nav-link <?php echo e(request()->routeIs('course.*') ? 'active' : ''); ?> d-flex align-items-center gap-2">
                <i class="fa-solid fa-book"></i> Quản lý bài học
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('vocabularies.index')); ?>"
                class="nav-link <?php echo e(request()->routeIs('post.*') ? 'active' : ''); ?> d-flex align-items-center gap-2">
                <i class="fa-solid fa-font"></i> Quản lý từ vựng
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('quizzes.index')); ?>"
                class="nav-link <?php echo e(request()->routeIs('post.*') ? 'active' : ''); ?> d-flex align-items-center gap-2">
                <i class="fa-solid fa-circle-question"></i> Quản lý câu hỏi
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('user.index')); ?>"
                class="nav-link <?php echo e(request()->routeIs('post.*') ? 'active' : ''); ?> d-flex align-items-center gap-2">
                <i class="fa-solid fa-user"></i> Quản lý người dùng
            </a>
        </li>
        <li>
            <a href="#"
                class="nav-link <?php echo e(request()->routeIs('theme.*') ? 'active' : ''); ?> d-flex align-items-center gap-2">
                <i class="fa-solid fa-palette"></i>
                Giao diện
            </a>
        </li>
    </ul>
</aside>
<?php /**PATH D:\xampp\htdocs\backendenglish\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>