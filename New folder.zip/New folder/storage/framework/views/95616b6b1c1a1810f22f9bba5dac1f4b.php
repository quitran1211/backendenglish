<?php $__env->startSection('title', 'Quản lý từ vựng'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid p-4">

        
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="h4 fw-semibold mb-1">Quản lý từ vựng</h2>
                <div class="text-muted">Danh sách toàn bộ từ vựng trong hệ thống</div>
            </div>

            <div class="d-flex gap-2">
                <a href="<?php echo e(route('vocabularies.create')); ?>" class="btn btn-primary">
                    <i class="fa-solid fa-plus"></i> Thêm từ vựng
                </a>

                <a href="<?php echo e(route('vocabularies.importVocabularies')); ?>" class="btn btn-success">
                    <i class="fa-solid fa-file-import"></i> Import Excel
                </a>
            </div>
        </div>

        
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?php echo e(session('success')); ?>

                <button class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        
        <div class="rounded border bg-white shadow-sm">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th class="px-3">#</th>
                            <th>Từ vựng</th>
                            <th>Phiên âm</th>
                            <th>Loại từ</th>
                            <th>Nghĩa (VI)</th>
                            <th>Nghĩa (EN)</th>
                            <th class="text-center">Trạng thái</th>
                            <th class="text-center">Thao tác</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $vocabularies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $vocab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="px-3">
                                    <?php echo e($vocabularies->firstItem() + $index); ?>

                                </td>

                                <td class="fw-semibold">
                                    <?php echo e($vocab->word); ?>

                                </td>

                                <td class="text-muted">
                                    <?php echo e($vocab->pronunciation ?? '—'); ?>

                                </td>

                                <td>
                                    <span class="badge bg-info text-dark">
                                        <?php echo e($vocab->word_type ?? 'N/A'); ?>

                                    </span>
                                </td>

                                <td><?php echo e($vocab->meaning_vi); ?></td>
                                <td class="text-muted"><?php echo e($vocab->meaning_en); ?></td>

                                <td class="text-center">
                                    <?php if($vocab->is_active): ?>
                                        <span class="badge bg-success">Hoạt động</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Ẩn</span>
                                    <?php endif; ?>
                                </td>

                                <td class="text-center">
                                    <div class="btn-group btn-group-sm">
                                        <a href="<?php echo e(route('vocabularies.edit', $vocab->id)); ?>"
                                            class="btn btn-outline-primary" title="Chỉnh sửa">
                                            <i class="fa-solid fa-pen"></i>
                                        </a>

                                        <form action="<?php echo e(route('vocabularies.destroy', $vocab->id)); ?>" method="POST"
                                            onsubmit="return confirm('Xóa từ vựng này?')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="btn btn-outline-danger" title="Xóa">
                                                <i class="fa-solid fa-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="8" class="text-center text-muted py-4">
                                    Chưa có từ vựng nào
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            
            <?php if($vocabularies->hasPages()): ?>
                <div class="p-3 border-top">
                    <?php echo e($vocabularies->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\backendenglish\resources\views/admin/vocabulary/index.blade.php ENDPATH**/ ?>