<?php $__env->startSection('title', 'Import từ vựng'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid p-4">

        <h2 class="h4 mb-4">Import từ vựng từ Excel</h2>

        
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        
        <?php if($errors->any()): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <div class="card shadow-sm rounded border p-3">
            <form action="<?php echo e(route('vocabularies.import')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="mb-3">
                    <input type="file" name="file" class="form-control" accept=".xlsx,.xls,.csv" required>
                </div>

                <button class="btn btn-success">
                    <i class="fa-solid fa-file-import"></i> Import từ Excel
                </button>

                <div class="form-text mt-2">
                    File Excel gồm các cột: <code>word</code>, <code>pronunciation</code>, <code>word_type</code>,
                    <code>meaning_vi</code>, <code>meaning_en</code>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\backendenglish\resources\views/admin/vocabularies/importExcel.blade.php ENDPATH**/ ?>