<?php $__env->startSection('title', 'Quản lý Câu hỏi'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid p-4">

        <!-- HEADER -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h4 class="fw-semibold mb-1">Câu hỏi của Quiz</h4>
                <div class="text-muted small">
                    <?php echo e($quiz->title); ?> • <?php echo e($questions->count()); ?> câu hỏi
                </div>
            </div>

            <div class="d-flex gap-2">
                <a href="<?php echo e(route('quizzes.questions.index', $quiz->id)); ?>" class="btn btn-secondary btn-sm">
                    Quay lại Quiz
                </a>
                <a href="<?php echo e(route('quizzes.questions.create', $quiz->id)); ?>" class="btn btn-primary btn-sm">
                    Thêm câu hỏi
                </a>
                <a href="<?php echo e(route('quizzes.questions.trash', $quiz->id)); ?>" class="btn btn-outline-secondary btn-sm">
                    Thùng rác
                </a>
            </div>
        </div>

        <!-- ALERT -->
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- TABLE -->
        <div class="card">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Câu hỏi</th>
                            <th width="160" class="text-center">Từ vựng</th>
                            <th width="140" class="text-center">Loại</th>
                            <th width="80" class="text-center">Điểm</th>
                            <th width="100" class="text-center">Thứ tự</th>
                            <th width="150" class="text-center">Thao tác</th>
                            <th width="60" class="text-center">ID</th>
                            <th width="60" class="text-center"></th>


                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <div class="fw-semibold">
                                        <?php echo e(Str::limit($question->question_text, 80)); ?>

                                    </div>
                                    <small class="text-muted">
                                        Đáp án đúng: <strong><?php echo e($question->correct_answer); ?></strong>
                                    </small>
                                </td>

                                <td>
                                    <?php if($question->vocabulary): ?>
                                        <span class="badge bg-info">
                                            <?php echo e($question->vocabulary->word); ?>

                                        </span>
                                    <?php else: ?>
                                        <span class="text-muted">—</span>
                                    <?php endif; ?>
                                </td>

                                <td>
                                    <span class="badge bg-secondary">
                                        <?php echo e($question->question_type); ?>

                                    </span>
                                </td>

                                <td class="text-center">
                                    <?php echo e($question->points); ?>

                                </td>

                                <td class="text-center">
                                    <?php echo e($question->display_order); ?>

                                </td>

                                <td class="text-center">
                                    <div class="d-flex justify-content-center gap-2">
                                        <!-- Edit -->
                                        <a href="<?php echo e(route('quizzes.questions.edit', [$quiz->id, $question->id])); ?>"
                                            class="text-primary text-decoration-none">
                                            <i class="fa-solid fa-pen-to-square"></i>
                                        </a>

                                        <!-- Soft delete -->
                                        <a href="<?php echo e(route('quizzes.questions.delete', [$quiz->id, $question->id])); ?>"
                                            onclick="return confirm('Bạn chắc chắn muốn xóa câu hỏi này?')"
                                            class="text-danger text-decoration-none">
                                            <i class="fa-solid fa-trash"></i>
                                        </a>
                                    </div>
                                </td>
                                <td class="text-center"><?php echo e($question->id); ?></td>
                                <td class="px-4 py-3 text-center">
                                    <a href="<?php echo e(route('quizzes.questions.show', [$quiz->id, $question->id])); ?>"
                                        class="text-primary text-decoration-none">
                                        Xem
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center text-muted py-4">
                                    Chưa có câu hỏi nào
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\backendenglish\resources\views/admin/quiz_questions/index.blade.php ENDPATH**/ ?>