<?php $__env->startSection('title', 'Chỉnh sửa Câu hỏi'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid p-4">

        <!-- HEADER -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="h4 fw-semibold">Chỉnh sửa Câu hỏi</h2>
            <a href="<?php echo e(route('quizzes.index')); ?>" class="btn btn-secondary">
                <i class="fa-solid fa-arrow-left"></i> Quay lại
            </a>
        </div>

        <!-- FORM -->
        <div class="card shadow-sm">
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('quizzes.update', $quiz->id)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="row g-3">

                        <!-- Lesson -->
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Bài học *</label>
                            <select name="lesson_id" class="form-select <?php $__errorArgs = ['lesson_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                <option value="">-- Chọn bài học --</option>
                                <?php $__currentLoopData = $lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($lesson->id); ?>"
                                        <?php echo e(old('lesson_id', $quiz->lesson_id) == $lesson->id ? 'selected' : ''); ?>>
                                        <?php echo e($lesson->title); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['lesson_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Level -->
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Mức độ *</label>
                            <select name="level_id" class="form-select <?php $__errorArgs = ['level_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                <option value="">-- Chọn mức độ --</option>
                                <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($level->id); ?>"
                                        <?php echo e(old('level_id', $quiz->level_id) == $level->id ? 'selected' : ''); ?>>
                                        <?php echo e($level->level_name); ?> (<?php echo e($level->target_score); ?>)
                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['level_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Title -->
                        <div class="col-md-8">
                            <label class="form-label fw-semibold">Tiêu đề *</label>
                            <input type="text" name="title" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                value="<?php echo e(old('title', $quiz->title)); ?>" required>
                            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Description -->
                        <div class="col-md-12">
                            <label class="form-label">Mô tả</label>
                            <textarea name="description" rows="3" class="form-control">
<?php echo e(old('description', $quiz->description)); ?></textarea>
                        </div>

                        <!-- Quiz Type -->
                        <div class="col-md-4">
                            <label class="form-label">Loại Quiz</label>
                            <select name="quiz_type" class="form-select" required>
                                <?php $__currentLoopData = ['vocabulary', 'multiple_choice', 'listening']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($type); ?>"
                                        <?php echo e(old('quiz_type', $quiz->quiz_type) == $type ? 'selected' : ''); ?>>
                                        <?php echo e(ucfirst(str_replace('_', ' ', $type))); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <!-- Time Limit -->
                        <div class="col-md-4">
                            <label class="form-label">Thời gian (phút)</label>
                            <input type="number" name="time_limit" class="form-control"
                                value="<?php echo e(old('time_limit', $quiz->time_limit)); ?>" min="0">
                        </div>

                        <!-- Passing Score -->
                        <div class="col-md-4">
                            <label class="form-label">Điểm đạt (%)</label>
                            <input type="number" name="passing_score" class="form-control"
                                value="<?php echo e(old('passing_score', $quiz->passing_score)); ?>" min="0" max="100"
                                required>
                        </div>

                        <!-- Switches -->
                        <div class="col-md-6">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" name="is_free" value="1"
                                    <?php echo e(old('is_free', $quiz->is_free) ? 'checked' : ''); ?>>
                                <label class="form-check-label">Miễn phí</label>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" name="is_active" value="1"
                                    <?php echo e(old('is_active', $quiz->is_active) ? 'checked' : ''); ?>>
                                <label class="form-check-label">Kích hoạt</label>
                            </div>
                        </div>

                        <!-- Buttons -->
                        <div class="col-12 text-end">
                            <a href="<?php echo e(route('quizzes.index')); ?>" class="btn btn-secondary">Hủy</a>
                            <button class="btn btn-primary">
                                <i class="fa-solid fa-save"></i> Cập nhật
                            </button>
                        </div>

                    </div>
                </form>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\backendenglish\resources\views/admin/quizzes/edit.blade.php ENDPATH**/ ?>