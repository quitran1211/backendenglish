<script>
    <?php if(session('success')): ?>
        toastr.success("<?php echo e(session('success')); ?>", "Thông báo");
    <?php endif; ?>
    <?php if(session('info')): ?>
        toastr.info("<?php echo e(session('info')); ?>", "Thông báo");
    <?php endif; ?>
    <?php if(session('warning')): ?>
        toastr.warning("<?php echo e(session('warning')); ?>", "Thông báo");
    <?php endif; ?>
    <?php if(session('error')): ?>
        toastr.error("<?php echo e(session('error')); ?>", "Thông báo");
    <?php endif; ?>
</script>
<?php /**PATH D:\xampp\htdocs\backendenglish\resources\views/admin/notifications.blade.php ENDPATH**/ ?>