<?php $__env->startSection('title', 'Quản lý Cấp độ'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid p-4">

        <!-- ===== HEADER ===== -->
        <div class="d-flex align-items-center justify-content-between rounded border bg-white p-4 shadow-sm mb-4">
            <div>
                <h2 class="h4 fw-semibold mb-1 text-dark">Quản lý Cấp độ</h2>
                <p class="text-muted mb-0 small">Tổng cộng: <?php echo e($levels->total()); ?> cấp độ</p>
            </div>

            <div class="d-flex gap-2">
                <a href="<?php echo e(route('levels.trash')); ?>" class="btn btn-outline-secondary">
                    <i class="fa-solid fa-trash"></i> Thùng rác
                </a>
                <a href="<?php echo e(route('levels.create')); ?>" class="btn btn-primary">
                    <i class="fa-solid fa-plus"></i> Thêm cấp độ
                </a>
            </div>
        </div>


        <!-- ===== FILTER ===== -->
        <div class="rounded border bg-white p-3 shadow-sm mb-4">
            <form method="GET">
                <div class="row g-3 align-items-end">
                    <div class="col-md-4">
                        <label class="form-label small fw-semibold">Tìm kiếm</label>
                        <input type="text" name="search" class="form-control" placeholder="Mã hoặc tên cấp độ"
                            value="<?php echo e(request('search')); ?>">
                    </div>

                    <div class="col-md-3">
                        <label class="form-label small fw-semibold">Trạng thái</label>
                        <select name="status" class="form-select">
                            <option value="">-- Tất cả --</option>
                            <option value="1" <?php if(request('status') === '1'): echo 'selected'; endif; ?>>Hoạt động</option>
                            <option value="0" <?php if(request('status') === '0'): echo 'selected'; endif; ?>>Tắt</option>
                        </select>
                    </div>

                    <div class="col-md-2">
                        <label class="form-label small fw-semibold">Sắp xếp</label>
                        <select name="sort" class="form-select">
                            <option value="display_order">Thứ tự</option>
                            <option value="target_score">Điểm</option>
                            <option value="created_at">Mới nhất</option>
                        </select>
                    </div>

                    <div class="col-md-3 d-flex gap-2">
                        <button class="btn btn-primary flex-grow-1">
                            <i class="fa-solid fa-magnifying-glass"></i> Tìm
                        </button>
                        <a href="<?php echo e(route('levels.index')); ?>" class="btn btn-secondary">
                            <i class="fa-solid fa-rotate-right"></i>
                        </a>
                    </div>
                </div>
            </form>
        </div>

        <!-- ===== TABLE ===== -->
        <div class="rounded border bg-white shadow-sm">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th class="text-center" width="120">Mã</th>
                            <th>Tên cấp độ</th>
                            <th class="text-center">Màu</th>
                            <th class="text-center" width="140">Điểm</th>
                            <th class="text-center">Từ vựng</th>
                            <th class="text-center">Thứ tự</th>
                            <th class="text-center">Trạng thái</th>
                            <th class="text-center" width="140">Thao tác</th>
                            <th class="text-center" width="60">ID</th>
                            <th class="text-center" width="60"></th>

                        </tr>
                    </thead>

                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="px-4 py-3 ">
                                    <span class="badge bg-secondary"><?php echo e($level->level_code); ?></span>
                                </td>
                                <td>
                                    <div class="fw-semibold"><?php echo e($level->level_name); ?></div>
                                    <?php if($level->description): ?>
                                        <small class="text-muted">
                                            <?php echo e(Str::limit($level->description, 50)); ?>

                                        </small>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <?php if($level->color): ?>
                                        <span class="badge" style="background-color: <?php echo e($level->color); ?>">
                                            <?php echo e($level->color); ?>

                                        </span>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </td>
                                <td class="text-center text-primary fw-semibold">
                                    <?php echo e($level->target_score); ?>

                                </td>
                                <td class="text-center">
                                    <span class="badge bg-info"><?php echo e($level->total_words ?? 0); ?></span>
                                </td>
                                <td class="text-center">
                                    <span class="badge bg-dark"><?php echo e($level->display_order); ?></span>
                                </td>
                                <!-- Trạng thái -->
                                <td class="text-center">
                                    <?php if($level->is_active): ?>
                                        <span class="badge bg-success bg-opacity-10 text-success px-3 py-2 rounded-pill">
                                            Hoạt động
                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-danger bg-opacity-10 text-danger px-3 py-2 rounded-pill">
                                            Tạm ẩn
                                        </span>
                                    <?php endif; ?>
                                </td>

                                <td class="text-center">
                                    <div class="d-inline-flex align-items-center gap-3">

                                        <!-- Toggle status -->
                                        <a href="<?php echo e(route('levels.toggleStatus', $level->id)); ?>" title="Bật / Tắt"
                                            class="text-decoration-none">
                                            <?php if($level->is_active): ?>
                                                <i class="fa-solid fa-toggle-on text-success fs-5"></i>
                                            <?php else: ?>
                                                <i class="fa-solid fa-toggle-off text-danger fs-5"></i>
                                            <?php endif; ?>
                                        </a>
                                        <a href="<?php echo e(route('levels.edit', $level->id)); ?>"
                                            class="text-primary text-decoration-none">
                                            <i class="fa-solid fa-pen"></i>
                                        </a>
                                        <form action="<?php echo e(route('levels.destroy', $level->id)); ?>" method="POST"
                                            class="d-inline" onsubmit="return confirm('Bạn có chắc muốn xóa cấp độ này?')">
                                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                            <button class="text-danger text-decoration-none ">
                                                <i class="fa-solid fa-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                                <td class="text-center px-4 py-3">
                                    <?php echo e($level->id); ?>

                                </td>

                                <td class="px-4 py-3 text-center">
                                    <a href="<?php echo e(route('levels.show', $level->id)); ?>"
                                        class="text-primary text-decoration-none">
                                        Xem
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="9" class="text-center py-5 text-muted">
                                    Chưa có cấp độ nào
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="p-3 border-top">
                <?php echo e($levels->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\backendenglish\resources\views/admin/levels/index.blade.php ENDPATH**/ ?>