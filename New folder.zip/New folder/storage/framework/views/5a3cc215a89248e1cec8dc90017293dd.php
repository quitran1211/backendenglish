<?php $__env->startSection('title', 'Tạo Quiz mới'); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <div class="row mb-3">
            <div class="col">
                <h1 class="h3">Tạo Quiz mới</h1>
            </div>
        </div>

        ```
        <div class="card shadow-sm">
            <div class="card-body">
                <form action="<?php echo e(route('quizzes.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    
                    <div class="mb-3">
                        <label class="form-label">Level</label>
                        <select name="level_id" class="form-select" required>
                            <option value="">-- Chọn level --</option>
                            <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($level->id); ?>" <?php if(old('level_id') == $level->id): echo 'selected'; endif; ?>>
                                    <?php echo e($level->level_name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['level_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger small"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div class="mb-3">
                        <label class="form-label">Lesson</label>
                        <select name="lesson_id" class="form-select" required>
                            <option value="">-- Chọn lesson --</option>
                            <?php $__currentLoopData = $lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($lesson->id); ?>" <?php if(old('lesson_id') == $lesson->id): echo 'selected'; endif; ?>>
                                    <?php echo e($lesson->title); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['lesson_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger small"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div class="mb-3">
                        <label class="form-label">Tiêu đề Quiz</label>
                        <input type="text" name="title" class="form-control" value="<?php echo e(old('title')); ?>" required>
                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger small"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div class="mb-3">
                        <label class="form-label">Mô tả</label>
                        <textarea name="description" rows="3" class="form-control"><?php echo e(old('description')); ?></textarea>
                    </div>

                    
                    <div class="mb-3">
                        <label class="form-label">Loại Quiz</label>
                        <select name="quiz_type" class="form-select" required>
                            <option value="vocabulary">Vocabulary</option>
                            <option value="multiple_choice">Multiple Choice</option>
                            <option value="listening">Listening</option>
                        </select>
                    </div>

                    
                    <div class="mb-3">
                        <label class="form-label">Thời gian làm bài (phút)</label>
                        <input type="number" name="time_limit" class="form-control" value="<?php echo e(old('time_limit')); ?>"
                            min="0">
                    </div>

                    
                    <div class="mb-3">
                        <label class="form-label">Điểm đạt (%)</label>
                        <input type="number" name="passing_score" class="form-control"
                            value="<?php echo e(old('passing_score', 70)); ?>" min="0" max="100" required>
                    </div>

                    
                    <div class="form-check mb-4">
                        <input class="form-check-input" type="checkbox" name="is_active" value="1" checked>
                        <label class="form-check-label">Kích hoạt quiz</label>
                    </div>

                    <div class="d-flex justify-content-between">
                        <a href="<?php echo e(route('quizzes.index')); ?>" class="btn btn-secondary">Quay lại</a>
                        <button type="submit" class="btn btn-primary">Lưu Quiz</button>
                    </div>
                </form>
            </div>
        </div>
        ```

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\backendenglish\resources\views/admin/quizzes/create.blade.php ENDPATH**/ ?>