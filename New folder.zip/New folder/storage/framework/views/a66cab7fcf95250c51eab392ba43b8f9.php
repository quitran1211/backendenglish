<?php $__env->startSection('title', 'Chi tiết Cấp độ'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid p-4">

        <!-- HEADER -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h4 class="fw-semibold mb-0">Chi tiết Cấp độ</h4>
            <a href="<?php echo e(route('levels.index')); ?>" class="btn btn-secondary btn-sm">
                Quay lại
            </a>
        </div>

        <!-- BASIC INFO -->
        <div class="card mb-4">
            <div class="card-header fw-semibold">
                Thông tin cấp độ
            </div>
            <div class="card-body">
                <div class="row g-3 align-items-center">
                    <div class="col-md-3">
                        <label class="text-muted small">Mã cấp độ</label>
                        <div class="fw-semibold"><?php echo e($level->level_code); ?></div>
                    </div>

                    <div class="col-md-3">
                        <label class="text-muted small">Tên cấp độ</label>
                        <div class="fw-semibold"><?php echo e($level->level_name); ?></div>
                    </div>

                    <div class="col-md-3">
                        <label class="text-muted small">Trạng thái</label>
                        <div>
                            <span class="badge <?php echo e($level->is_active ? 'bg-success' : 'bg-secondary'); ?>">
                                <?php echo e($level->is_active ? 'Hoạt động' : 'Tạm tắt'); ?>

                            </span>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <label class="text-muted small">Điểm mục tiêu</label>
                        <div><?php echo e($level->target_score); ?></div>
                    </div>

                    <div class="col-md-3">
                        <label class="text-muted small">Tổng từ vựng</label>
                        <div><?php echo e($level->total_words ?? 0); ?></div>
                    </div>

                    <div class="col-md-3">
                        <label class="text-muted small">Thứ tự hiển thị</label>
                        <div><?php echo e($level->display_order ?? 0); ?></div>
                    </div>

                    <div class="col-md-3">
                        <label class="text-muted small">Màu sắc</label>
                        <div>
                            <?php if($level->color): ?>
                                <span class="badge text-white" style="background-color: <?php echo e($level->color); ?>">
                                    <?php echo e($level->color); ?>

                                </span>
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </div>
                    </div>

                    <?php if($level->description): ?>
                        <div class="col-12">
                            <label class="text-muted small">Mô tả</label>
                            <div class="border rounded p-2 bg-light">
                                <?php echo e($level->description); ?>

                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- LESSON LIST -->
        <div class="card mb-4">
            <div class="card-header fw-semibold">
                Danh sách bài học (<?php echo e($level->lessons->count()); ?>)
            </div>
            <div class="card-body p-0">
                <?php if($level->lessons->isNotEmpty()): ?>
                    <div class="table-responsive">
                        <table class="table table-sm table-hover mb-0 text-center align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th width="60">#</th>
                                    <th class="text-start">Tiêu đề</th>
                                    <th width="120">Từ vựng</th>
                                    <th width="120">Trạng thái</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $level->lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($index + 1); ?></td>
                                        <td class="text-start"><?php echo e($lesson->title); ?></td>
                                        <td><?php echo e($lesson->word_count ?? 0); ?></td>
                                        <td>
                                            <span class="badge <?php echo e($lesson->is_active ? 'bg-success' : 'bg-secondary'); ?>">
                                                <?php echo e($lesson->is_active ? 'Hoạt động' : 'Tắt'); ?>

                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="p-3 text-muted text-center">
                        Chưa có bài học nào.
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- ACTIONS -->
        <div class="d-flex gap-2">
            <a href="<?php echo e(route('levels.edit', $level->id)); ?>" class="btn btn-primary">
                Chỉnh sửa
            </a>

            <form action="<?php echo e(route('levels.toggleStatus', $level->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button class="btn <?php echo e($level->is_active ? 'btn-warning' : 'btn-success'); ?>">
                    <?php echo e($level->is_active ? 'Tắt kích hoạt' : 'Kích hoạt'); ?>

                </button>
            </form>

            <form action="<?php echo e(route('levels.destroy', $level->id)); ?>" method="POST"
                onsubmit="return confirm('Xóa cấp độ này?')">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button class="btn btn-danger">
                    Xóa
                </button>
            </form>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\backendenglish\resources\views/admin/levels/show.blade.php ENDPATH**/ ?>