<?php $__env->startSection('title', 'Thùng rác - Cấp độ'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid p-4">

        <!-- ===== HEADER ===== -->
        <div class="d-flex align-items-center justify-content-between rounded border bg-white p-4 shadow-sm mb-4">
            <div>
                <h2 class="h4 fw-semibold mb-1 text-dark">
                    <i class="fa-solid fa-trash text-danger"></i> Thùng rác - Cấp độ
                </h2>
                <p class="text-muted mb-0 small">Tổng cộng: <?php echo e($levels->total()); ?> mục đã xóa</p>
            </div>

            <div class="d-flex gap-2">
                <form action="<?php echo e(route('levels.trash.empty')); ?>" method="POST"
                    onsubmit="return confirm('Bạn có chắc muốn xóa vĩnh viễn TẤT CẢ các mục trong thùng rác?')">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-danger">
                        <i class="fa-solid fa-trash-can"></i> Xóa tất cả
                    </button>
                </form>
                <a href="<?php echo e(route('levels.index')); ?>" class="btn btn-secondary">
                    <i class="fa-solid fa-arrow-left"></i> Quay lại
                </a>
            </div>
        </div>

        <!-- ===== ALERT MESSAGES ===== -->
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="fa-solid fa-circle-check"></i> <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="fa-solid fa-circle-exclamation"></i> <?php echo e(session('error')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- ===== TABLE ===== -->
        <div class="rounded border bg-white shadow-sm">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th width="80">STT</th>
                            <th width="120">Mã cấp độ</th>
                            <th>Tên cấp độ</th>
                            <th width="120" class="text-center">Điểm mục tiêu</th>
                            <th width="120" class="text-center">Tổng từ vựng</th>
                            <th width="180" class="text-center">Ngày xóa</th>
                            <th width="180" class="text-center">Thao tác</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="opacity-75">
                                <td><?php echo e($levels->firstItem() + $index); ?></td>
                                <td>
                                    <span class="badge bg-secondary"><?php echo e($level->level_code); ?></span>
                                </td>
                                <td>
                                    <div class="fw-semibold"><?php echo e($level->level_name); ?></div>
                                    <?php if($level->description): ?>
                                        <small class="text-muted"><?php echo e(Str::limit($level->description, 50)); ?></small>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <strong class="text-primary"><?php echo e($level->target_score); ?></strong>
                                </td>
                                <td class="text-center">
                                    <span class="badge bg-info"><?php echo e($level->total_words ?? 0); ?></span>
                                </td>
                                <td class="text-center">
                                    <small class="text-muted">
                                        <i class="fa-solid fa-calendar"></i>
                                        <?php echo e($level->deleted_at->format('d/m/Y H:i')); ?>

                                        <br>
                                        <span class="badge bg-light text-dark">
                                            <?php echo e($level->deleted_at->diffForHumans()); ?>

                                        </span>
                                    </small>
                                </td>
                                <td class="text-center">
                                    <div class="d-flex gap-2 justify-content-center">
                                        <form action="<?php echo e(route('levels.restore', $level->id)); ?>" method="POST"
                                            class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-sm btn-success" title="Khôi phục"
                                                onclick="return confirm('Bạn có muốn khôi phục cấp độ này?')">
                                                <i class="fa-solid fa-rotate-left"></i> Khôi phục
                                            </button>
                                        </form>
                                        <form action="<?php echo e(route('levels.force-delete', $level->id)); ?>" method="POST"
                                            class="d-inline"
                                            onsubmit="return confirm('Bạn có chắc muốn xóa VĨNH VIỄN cấp độ này? Hành động này không thể hoàn tác!')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-danger" title="Xóa vĩnh viễn">
                                                <i class="fa-solid fa-trash-can"></i> Xóa vĩnh viễn
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center py-5 text-muted">
                                    <i class="fa-solid fa-inbox fa-3x mb-3 d-block"></i>
                                    <p class="mb-0">Thùng rác trống</p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <div class="p-3 border-top">
                <?php echo e($levels->links()); ?>

            </div>
        </div>

        <!-- Info Box -->
        <div class="alert alert-info mt-4">
            <i class="fa-solid fa-circle-info"></i>
            <strong>Lưu ý:</strong>
            Các mục trong thùng rác sẽ được xóa vĩnh viễn sau 30 ngày.
            Bạn có thể khôi phục hoặc xóa vĩnh viễn trước thời hạn đó.
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\backendenglish\resources\views/admin/levels/trash.blade.php ENDPATH**/ ?>