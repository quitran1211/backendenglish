<?php $__env->startSection('title', 'Thêm từ vựng'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid p-4">

        
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="h4 fw-semibold mb-1">Thêm từ vựng mới</h2>
                <div class="text-muted">Nhập thông tin từ vựng vào hệ thống</div>
            </div>

            <a href="<?php echo e(route('vocabularies.index')); ?>" class="btn btn-outline-secondary">
                <i class="fa-solid fa-arrow-left"></i> Quay lại
            </a>
        </div>

        
        <?php if($errors->any()): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <strong>Đã xảy ra lỗi!</strong>
                <ul class="mb-0 mt-2">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <button class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        
        <form action="<?php echo e(route('vocabularies.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="row g-4">

                
                <div class="col-md-6">
                    <label class="form-label fw-semibold">
                        Từ vựng <span class="text-danger">*</span>
                    </label>
                    <input type="text" name="word" class="form-control" value="<?php echo e(old('word')); ?>"
                        placeholder="Ví dụ: develop" required>
                </div>

                
                <div class="col-md-6">
                    <label class="form-label fw-semibold">
                        Phiên âm
                    </label>
                    <input type="text" name="pronunciation" class="form-control" value="<?php echo e(old('pronunciation')); ?>"
                        placeholder="/dɪˈveləp/">
                </div>

                
                <div class="col-md-4">
                    <label class="form-label fw-semibold">
                        Loại từ
                    </label>
                    <select name="word_type" class="form-select">
                        <option value="">-- Chọn loại từ --</option>
                        <?php $__currentLoopData = ['noun', 'verb', 'adjective', 'adverb', 'pronoun', 'preposition', 'conjunction', 'interjection']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($type); ?>" <?php if(old('word_type') === $type): echo 'selected'; endif; ?>>
                                <?php echo e(ucfirst($type)); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                
                <div class="col-md-4">
                    <label class="form-label fw-semibold">
                        Trạng thái
                    </label>
                    <select name="is_active" class="form-select">
                        <option value="1" <?php if(old('is_active', 1) == 1): echo 'selected'; endif; ?>>Hoạt động</option>
                        <option value="0" <?php if(old('is_active') == 0): echo 'selected'; endif; ?>>Ẩn</option>
                    </select>
                </div>

                
                <div class="col-md-12">
                    <label class="form-label fw-semibold">
                        Nghĩa tiếng Việt <span class="text-danger">*</span>
                    </label>
                    <textarea name="meaning_vi" rows="3" class="form-control" placeholder="Nhập nghĩa tiếng Việt" required><?php echo e(old('meaning_vi')); ?></textarea>
                </div>

                
                <div class="col-md-12">
                    <label class="form-label fw-semibold">
                        Nghĩa tiếng Anh
                    </label>
                    <textarea name="meaning_en" rows="3" class="form-control" placeholder="English definition"><?php echo e(old('meaning_en')); ?></textarea>
                </div>

            </div>

            
            <div class="mt-4 d-flex gap-2">
                <button class="btn btn-primary">
                    <i class="fa-solid fa-save"></i> Lưu từ vựng
                </button>

                <a href="<?php echo e(route('vocabularies.index')); ?>" class="btn btn-outline-secondary">
                    Huỷ
                </a>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\backendenglish\resources\views/admin/vocabularies/create.blade.php ENDPATH**/ ?>