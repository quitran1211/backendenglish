<?php $__env->startSection('title', 'Quiz'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid p-4">

        <!-- ===== HEADER ===== -->
        <div class="d-flex align-items-center justify-content-between rounded border bg-white p-4 shadow-sm mb-4">
            <h2 class="h4 fw-semibold mb-0 text-dark">
                Quản lý câu hỏi
            </h2>

            <div class="d-flex align-items-center gap-3">
                <a href="<?php echo e(route('quizzes.create')); ?>"
                    class="d-inline-flex align-items-center gap-2 rounded bg-primary px-4 py-2 text-white text-decoration-none shadow-sm">
                    <i class="fa-solid fa-plus"></i>
                    <span>Thêm câu hỏi</span>
                </a>

                <a href="<?php echo e(route('quizzes.trash')); ?>"
                    class="d-inline-flex align-items-center gap-2 rounded bg-danger px-4 py-2 text-white text-decoration-none shadow-sm">
                    <i class="fa-solid fa-trash"></i>
                    <span>Thùng rác</span>
                </a>
            </div>
        </div>

        <!-- ===== TABLE ===== -->
        <div class="rounded border bg-white shadow-sm overflow-hidden">
            <div class="table-responsive">
                <table class="table table-hover mb-0 align-middle">
                    <thead class="table-light">
                        <tr class="text-secondary">
                            <th class="px-4 py-3">Tiêu đề</th>
                            <th class="px-4 py-3">Lesson</th>
                            <th class="px-4 py-3">Level</th>
                            <th class="px-4 py-3">Loại</th>
                            <th class="px-4 py-3 text-center">Trạng thái</th>
                            <th class="px-4 py-3 text-center">Thao tác</th>
                            <th class="px-4 py-3 text-center">ID</th>
                            <th class="px-4 py-3 text-center"></th>
                            <th class="px-4 py-3 text-center">Quản lý câu hỏi</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $quizzes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="hover-bg-light">
                                <td class="px-4 py-3 fw-medium">
                                    <?php echo e($item->title); ?>

                                </td>
                                <td class="px-4 py-3">
                                    <?php echo e($item->lesson?->title ?? '—'); ?>

                                </td>
                                <td class="px-4 py-3">
                                    <?php echo e($item->level?->level_name ?? '—'); ?>

                                </td>

                                <td class="px-4 py-3">
                                    <?php echo e($item->quiz_type); ?>

                                </td>

                                <!-- Trạng thái -->
                                <td class="px-4 py-3 text-center">
                                    <?php if($item->is_active): ?>
                                        <span class="badge bg-success bg-opacity-10 text-success px-3 py-2 rounded-pill">
                                            Hoạt động
                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-danger bg-opacity-10 text-danger px-3 py-2 rounded-pill">
                                            Tạm ẩn
                                        </span>
                                    <?php endif; ?>
                                </td>

                                <!-- Thao tác -->
                                <td class="px-4 py-3 text-center">
                                    <div class="d-inline-flex align-items-center gap-3">

                                        <!-- Toggle status -->
                                        <a href="<?php echo e(route('quizzes.toggleStatus', $item->id)); ?>" title="Bật / Tắt"
                                            class="text-decoration-none">
                                            <?php if($item->is_active): ?>
                                                <i class="fa-solid fa-toggle-on text-success fs-5"></i>
                                            <?php else: ?>
                                                <i class="fa-solid fa-toggle-off text-danger fs-5"></i>
                                            <?php endif; ?>
                                        </a>

                                        <!-- Edit -->
                                        <a href="<?php echo e(route('quizzes.edit', $item->id)); ?>"
                                            class="text-primary text-decoration-none">
                                            <i class="fa-solid fa-pen-to-square"></i>
                                        </a>

                                        <!-- Soft delete -->
                                        <a href="<?php echo e(route('quizzes.delete', $item->id)); ?>"
                                            onclick="return confirm('Bạn chắc chắn muốn xóa bài học này?')"
                                            class="text-danger text-decoration-none">
                                            <i class="fa-solid fa-trash"></i>
                                        </a>
                                    </div>
                                </td>

                                <td class="px-4 py-3 text-center text-secondary">
                                    <?php echo e($item->id); ?>

                                </td>

                                <td class="px-4 py-3 text-center">
                                    <a href="<?php echo e(route('quizzes.show', $item->id)); ?>"
                                        class="text-primary text-decoration-none">
                                        Xem
                                    </a>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('quizzes.questions.index', $item->id)); ?>"
                                        class="btn btn-sm btn-primary">
                                        Quản lý câu hỏi
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center text-muted py-4">
                                    Không có bài học nào
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <div class="border-top p-4">
                <?php echo e($quizzes->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\backendenglish\resources\views/admin/quizzes/index.blade.php ENDPATH**/ ?>