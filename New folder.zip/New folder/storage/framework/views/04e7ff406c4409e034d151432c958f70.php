<?php $__env->startSection('title', 'Chi tiết bài học'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid p-4">

        <!-- ===== HEADER ===== -->
        <div class="d-flex align-items-center justify-content-between rounded border bg-white p-4 shadow-sm mb-4">
            <div>
                <h2 class="h4 fw-semibold mb-1 text-dark">
                    <?php echo e($lesson->title); ?>

                </h2>
                <div class="text-muted">
                    Level: <strong><?php echo e($lesson->level?->level_name ?? '—'); ?></strong>
                </div>
            </div>

            <div class="d-flex align-items-center gap-3">
                <a href="<?php echo e(route('lesson.index')); ?>" class="btn btn-secondary">
                    <i class="fa-solid fa-arrow-left"></i>
                    Quay lại
                </a>

                <a href="<?php echo e(route('lesson.edit', $lesson->id)); ?>" class="btn btn-primary">
                    <i class="fa-solid fa-pen-to-square"></i>
                    Chỉnh sửa
                </a>

                <a href="<?php echo e(route('lesson.manageVocabularies', $lesson->id)); ?>" class="btn btn-success">
                    <i class="fa-solid fa-book"></i>
                    Từ vựng
                </a>
            </div>
        </div>

        <!-- ===== STATS ===== -->
        <div class="row g-4 mb-4">
            <div class="col-md-4">
                <div class="card shadow-sm h-100">
                    <div class="card-body">
                        <h6 class="text-muted">Tổng từ vựng</h6>
                        <h2 class="fw-bold text-primary">
                            <?php echo e($stats['total_vocabularies']); ?>

                        </h2>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card shadow-sm h-100">
                    <div class="card-body">
                        <h6 class="text-muted">Số học viên</h6>
                        <h2 class="fw-bold text-success">
                            <?php echo e($stats['total_students']); ?>

                        </h2>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card shadow-sm h-100">
                    <div class="card-body">
                        <h6 class="text-muted">Hoàn thành</h6>
                        <h2 class="fw-bold text-warning">
                            <?php echo e($stats['completion_rate']); ?>

                        </h2>
                    </div>
                </div>
            </div>
        </div>

        <!-- ===== INFO ===== -->
        <div class="row g-4 mb-4">
            <div class="col-md-8">
                <div class="card shadow-sm h-100">
                    <div class="card-body">
                        <h5 class="fw-semibold mb-3">Thông tin bài học</h5>

                        <div class="mb-2">
                            <strong>Chủ đề:</strong>
                            <div class="text-muted">
                                <?php echo e($lesson->topic); ?>

                            </div>
                        </div>

                        <div class="mb-2">
                            <strong>Mô tả:</strong>
                            <div class="text-muted">
                                <?php echo e($lesson->description ?? '—'); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card shadow-sm h-100">
                    <div class="card-body">
                        <h5 class="fw-semibold mb-3">Trạng thái</h5>

                        <div class="mb-2">
                            <strong>Kích hoạt:</strong>
                            <?php if($lesson->is_active): ?>
                                <span class="badge bg-success">Hoạt động</span>
                            <?php else: ?>
                                <span class="badge bg-danger">Tạm ẩn</span>
                            <?php endif; ?>
                        </div>

                        <div class="mb-2">
                            <strong>Loại:</strong>
                            <?php if($lesson->is_free): ?>
                                <span class="badge bg-primary">Miễn phí</span>
                            <?php else: ?>
                                <span class="badge bg-warning text-dark">Trả phí</span>
                            <?php endif; ?>
                        </div>

                        <div class="mb-2">
                            <strong>Số từ:</strong>
                            <?php echo e($lesson->vocabularies_count); ?>

                        </div>

                        <div class="mb-2">
                            <strong>Thứ tự hiển thị:</strong>
                            <?php echo e($lesson->display_order); ?>

                        </div>

                        <div class="mb-2">
                            <strong>Ngày tạo:</strong>
                            <?php echo e($lesson->created_at->format('d/m/Y H:i')); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ===== VOCABULARY LIST ===== -->
        <div class="card shadow-sm">
            <div class="card-body">
                <h5 class="fw-semibold mb-3">Danh sách từ vựng</h5>

                <?php if($lesson->vocabularies->count()): ?>
                    <ul class="list-group list-group-flush">
                        <?php $__currentLoopData = $lesson->vocabularies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vocab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item d-flex justify-content-between">
                                <div>
                                    <strong><?php echo e($vocab->word); ?></strong>
                                    <span class="text-muted ms-2">
                                        <?php echo e($vocab->meaning); ?>

                                    </span>
                                </div>

                                <span class="text-muted">
                                    #<?php echo e($vocab->pivot->display_order); ?>

                                </span>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php else: ?>
                    <div class="text-muted">
                        Chưa có từ vựng nào trong bài học
                    </div>
                <?php endif; ?>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\backendenglish\resources\views/admin/lesson/show.blade.php ENDPATH**/ ?>