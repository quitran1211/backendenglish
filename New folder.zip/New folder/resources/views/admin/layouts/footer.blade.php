<footer class="bg-gradient-to-r from-yellow-500 to-amber-600 text-white text-center py-3 shadow-md">
    Thiết kế bởi: Trần Thị Kim Quí
</footer>
