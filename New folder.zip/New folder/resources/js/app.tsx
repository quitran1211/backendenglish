// File entry rỗng nhưng hợp lệ
console.log('App entry placeholder');
